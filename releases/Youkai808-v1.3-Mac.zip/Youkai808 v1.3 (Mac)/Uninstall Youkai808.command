#!/bin/bash
# Removes Youkai808 (VST3 + Audio Unit). Your presets and license key are kept.
echo "Uninstalling Youkai808 - you'll be asked for your Mac password."
sudo rm -rf "/Library/Audio/Plug-Ins/VST3/Youkai808.vst3" \
            "/Library/Audio/Plug-Ins/Components/Youkai808.component" \
            "/Library/Audio/Plug-Ins/VST3/Youkai808 Synth.vst3" \
            "/Library/Audio/Plug-Ins/Components/Youkai808 Synth.component"
sudo pkgutil --forget com.youkaidigital.youkai808.pkg >/dev/null 2>&1
killall -9 AudioComponentRegistrar >/dev/null 2>&1
echo "Done. Youkai808 has been removed."
echo "(Presets in Documents/YoukaiDigital and your license key were left alone.)"
