YOUKAI808  v1.3  -  experimental 808 destroyer (VST3 + AU, macOS universal)
© 2026 YoukaiDigital Inc. A Gensokyo LLC Company. All rights reserved.
Made by Skarlet Bandxz  -  https://soundcloud.com/skarletbandxz
========================================================================

REBUILT OLDER VERSION
  This is v1.3 rebuilt with the VERSIONS button (top right), so you can always
  jump back to the newest version. Everything else is how v1.3 was.

INSTALL
  Close your DAW, then double-click Youkai808-v1.3-mac.pkg.
  If macOS says it "can't be opened": right-click the .pkg > Open > Open,
  or (macOS 15+) System Settings > Privacy & Security > Open Anyway.
  Installs to /Library/Audio/Plug-Ins/VST3 and /Library/Audio/Plug-Ins/Components (AU).
  Uninstall: double-click "Uninstall Youkai808.command".
  FL Studio: Options > Manage plugins > Find plugins, then star Youkai808.

ACTIVATE
  Click ACTIVATE (top right), then COPY ID and send that ID with your order.
  Paste the license key you get back and click ACTIVATE. Keys keep working in every version.
  Until then it runs as a demo: a short dropout every 45 seconds, no preset saving.

VERSIONS BUTTON (top right, under ACTIVATE)
  Shows the version you have. It turns green and says UPDATE when a newer one is out.
  Click it to download the newest version, or any version from v1.2 up.

WHAT'S NEW IN v1.3
  - New CRT art: only Remilia shakes now, the frame stays still.
  - Knobs lined up with the art; Goblin presets removed.

NOT IN THIS VERSION (added later - use the VERSIONS button to upgrade)
  v1.4  TONE (dark <-> bright) in the ADVANCED tab.
        RANDOMIZE also rolls DRIVE, CHAOS, FAT, MIX and BASS GUARD.
        Presets and RANDOMIZE never touch OUTPUT.
        Real installer + uninstaller; license keys only need the computer ID; first Mac version.
  v1.5  Waveshaper effect: 16 curves + morph + bias.
        Youkai808 Synth: a second plugin (instrument) with a wavetable 808 voice and the whole effect chain.
  v1.6  Synth: 9 built-in 808 samples (tuned to C).
        Synth: ATTACK / DECAY / RELEASE / TENSION knobs + envelope picture.
        RANDOMIZE: Waveshaper in about half the chains, way less chorus/phaser/SFX, more variety.
  v1.7  Busted Speaker, Auto-Wah, Boing and Fly-By effects (30 effects).
        CURSED: drag Remilia's screen up to curse everything.
  v1.8  VERSIONS button: update alerts + download any version.
        Community preset bank: everyone's shared presets show up under COMMUNITY.

HOVER OVER ANYTHING for a short explanation of what it does.

THE 6 BIG KNOBS
  DRIVE       pushes the 808 harder into the whole chain
  CHAOS       pushes every effect further + controls how wild RANDOMIZE gets
  FAT         thick saturated low-mids, denser sustain, wider top
  MIX         clean 808 <-> destroyed 808
  BASS GUARD  left half: stops low-end buildup.  right half: also brings back the clean sub
  OUTPUT      final level (a limiter keeps it from clipping)

RANDOMIZE / MUTATE
  RANDOMIZE builds a brand new chain, MUTATE nudges the current one.
  Results stay until you change them. LOCK a slot and they won't touch it.

THE CHAIN (10 squares at the bottom)
  Click = edit.  Drag = rearrange.  Double-click = bypass.  Right-click = options.
  LAYER = run in parallel with the previous effect. Stack layers on layers.
  Each effect has its own PRESET menu next to the effect picker.

EFFECTS (25)
  Distortion, Overdrive, Slow Fuzz, Bitcrush (+Whine), Wavefold, High-Pass, Low-Pass,
  Chorus, Widener, SFX Layer, Ring Mod, Octave Screech, Formant Yell, Metal Comb,
  Stutter, Glitch, Freq Shifter, Smash, Gate/Chop, Wobble, Para EQ, Mod EQ, Phaser,
  Attack Shaper, Intro FX
  - Slow Fuzz: lazy, low fuzz with an octave-down buzz and a dying-battery sputter.
  - Intro FX: changes how every 808 comes in (Swell, Reverse, Scoop Up, Dive Down,
    Stutter-In, Filter Rise, Wobble-In, Crush-In).
  - Modulation (Chorus, Phaser, Mod EQ, Wobble) restarts on every 808 hit.
  - SFX "Sample": load any sound; it's stretched to the length of each 808 note.

ADVANCED tab
  Input, Bass Guard frequency, Mono Sub, Width, L/R Spread,
  Ceiling, Soft Attack, Limiter, Soft Clip, HQ 2x oversampling.

PRESETS
  Signature, Basics, Genre, Matched, Layers, Wobbly, Slow, Stupid.
  Your own presets: Documents/YoukaiDigital/Youkai808/Presets

REMILIA
  The CRT glows with your input volume, and the more extreme the 808 sounds, the more
  unhinged she gets. SANITY = how sane it sounds.

VERSION HISTORY
  v1.0  First release: 5 big knobs, 22 effects, RANDOMIZE / MUTATE, 42 factory presets, Remilia CRT.
  v1.1  License keys (ACTIVATE) + demo mode.
        Attack Shaper effect, Soft Attack (removes the kick-like thump), per-effect presets.
        Modulation restarts on every 808 hit; Signature presets (made by Skarlet).
  v1.2  FAT knob (6 big knobs), new UI art.
        Slow Fuzz and Intro FX effects (25 effects).
        Hover over anything for an explanation; color-matched menus, glossy buttons.
  v1.3  New CRT art: only Remilia shakes now, the frame stays still.  <- you are here
        Knobs lined up with the art; Goblin presets removed.
  v1.4  TONE (dark <-> bright) in the ADVANCED tab.
        RANDOMIZE also rolls DRIVE, CHAOS, FAT, MIX and BASS GUARD.
        Presets and RANDOMIZE never touch OUTPUT.
        Real installer + uninstaller; license keys only need the computer ID; first Mac version.
  v1.5  Waveshaper effect: 16 curves + morph + bias.
        Youkai808 Synth: a second plugin (instrument) with a wavetable 808 voice and the whole effect chain.
  v1.6  Synth: 9 built-in 808 samples (tuned to C).
        Synth: ATTACK / DECAY / RELEASE / TENSION knobs + envelope picture.
        RANDOMIZE: Waveshaper in about half the chains, way less chorus/phaser/SFX, more variety.
  v1.7  Busted Speaker, Auto-Wah, Boing and Fly-By effects (30 effects).
        CURSED: drag Remilia's screen up to curse everything.
  v1.8  VERSIONS button: update alerts + download any version.
        Community preset bank: everyone's shared presets show up under COMMUNITY.
  (v1.0 and v1.1 aren't available for download.)

More music: https://soundcloud.com/skarletbandxz
