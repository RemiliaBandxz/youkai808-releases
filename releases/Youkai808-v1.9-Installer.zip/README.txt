﻿YOUKAI808  v1.9  -  experimental 808 destroyer (VST3, Windows 64-bit)
(c) 2026 YoukaiDigital. All rights reserved.
SoundCloud: https://soundcloud.com/skarletbandxz
========================================================================

INSTALL
  Run Youkai808-v1.9-Setup.exe (close your DAW first). It installs Youkai808 + Youkai808 Synth to
  C:\Program Files\Common Files\VST3\ and adds an uninstaller to Windows Settings > Apps.
  Windows may say "Windows protected your PC": click More info > Run anyway.
  FL Studio: Options > Manage plugins > Find plugins, then star "Youkai808".

ACTIVATE
  Click ACTIVATE (top right), then COPY ID and send that ID with your order.
  Paste the license key you get back and click ACTIVATE.
  Until then it runs as a demo: a short dropout every 45 seconds, no preset saving.
  Your key keeps working in every version on the same computer.

VERSIONS button (top right)
  Shows your version and lights up when there's an update. Click it to download the newest
  version or ANY version from v1.2 up (handy if you want to go back to an older sound).

COMMUNITY PRESETS (new in v1.8)
  Presets shared by everyone show up in the COMMUNITY section of the preset menu
  automatically. To share yours: VERSIONS > Share your presets... and drag your .y808
  files into the Google Drive folder that opens.

YOUKAI808 SYNTH
  A second plugin: an instrument that makes the 808 itself, then runs it through the
  same effect chain. FL Studio: add it to the Channel Rack and play it like any synth.
  SYNTH tab:
    SOURCE      wavetables: 808 Sine, Analog, Pulse, Harmonics, FM, Vowel, Sync, Fold, Crushed,
                Growl, Buzz, USER (LOAD WT loads your own wavetable .wav - Serum tables work)
                808 samples: Plugg Sub, Pluggnb 808, Punchy Sub, Stereo Sub, Zay 1, Zay Punchy,
                Zay Stereo, Ambient, Jugg Sub - tuned to C, played across the keyboard
    POSITION    scans through the wavetable; on a sample: start offset
    GLIDE       overlapping notes slide into each other (808 slides)
    PUNCH       quick pitch drop at the start of each note
    ATTACK      fade-in time (left = instant hit)
    DECAY       how fast it fades while held (fully right = holds)
    RELEASE     how long it rings after you let go
    TENSION     bends the attack/decay/release curves (+ snappy, - swelly)
    TUNE        semitones up/down
  The FX and ADV tabs work exactly like in the effect. Presets are shared between both.

HOVER OVER ANYTHING for a short explanation of what it does.

THE 6 BIG KNOBS
  DRIVE       pushes the 808 harder into the whole chain
  CHAOS       pushes every effect further + controls how wild RANDOMIZE gets
  FAT         thick saturated low-mids, denser sustain, wider top
  MIX         clean 808 <-> destroyed 808
  BASS GUARD  left half: stops low-end buildup.  right half: also brings back the clean sub
  OUTPUT      final level (a limiter keeps it from clipping)

CURSED
  Drag Remilia's screen UP to curse everything: every effect is dragged toward its wildest
  setting, DRIVE goes up and every slot gets wetter. Drag down or double-click to un-curse.

RANDOMIZE / MUTATE
  RANDOMIZE builds a brand new chain and rolls DRIVE, CHAOS, FAT, MIX and BASS GUARD
  (OUTPUT never changes).
  MUTATE nudges the current chain. LOCK a slot and they won't touch it.

THE CHAIN (10 squares at the bottom)
  Click = edit.  Drag = rearrange.  Double-click = bypass.  Right-click = options.
  LAYER = run in parallel with the previous effect. Stack layers on layers.
  Each effect has its own PRESET menu next to the effect picker.

EFFECTS (30)
  Distortion, Overdrive, Slow Fuzz, Bitcrush (+Whine), Wavefold, High-Pass, Low-Pass,
  Chorus, Widener, SFX Layer, Ring Mod, Octave Screech, Formant Yell, Metal Comb,
  Stutter, Glitch, Freq Shifter, Smash, Gate/Chop, Wobble, Para EQ, Mod EQ, Phaser,
  Attack Shaper, Intro FX, Waveshaper, Busted Speaker, Auto-Wah, Boing, Fly-By
  - Slow Fuzz: lazy, low fuzz with an octave-down buzz and a dying-battery sputter.
  - Intro FX: changes how every 808 comes in (Swell, Reverse, Scoop Up, Dive Down,
    Stutter-In, Filter Rise, Wobble-In, Crush-In).
  - Modulation (Chorus, Phaser, Mod EQ, Wobble) restarts on every 808 hit.
  - Waveshaper: 16 curves (Soft/Hard Clip, Tube, Diode, Foldback, Sine Fold, Cheby 3, Cheby 5,
    Half/Full Rectify, Steps, Wrap, Ripple, Fuzz Spike, Bit Mangle, Crossover). MORPH blends into
    the next curve, BIAS makes it uneven. Stack several in the chain for a rack.
  - Busted Speaker: the 808 through a bad device - Phone, Laptop, Walkie-Talkie, AM Radio,
    Blown Woofer, Cheap Earbud, 2009 Upload, Toy - with cone RATTLE and STATIC.
  - Auto-Wah: Up, Down, Quack (sweeps on every note), Yoyo.
  - Boing: Spring, Pipe, String, Ruler resonators tuned to the 808, with a cartoon WOBBLE.
  - Fly-By: the 808 flies past your head with real Doppler pitch bend (Per Note, Loop, Random).
  - SFX "Sample": load any sound; it's stretched to the length of each 808 note.

ADVANCED tab
  Tone (dark <-> bright), Input, Bass Guard frequency, Mono Sub, Width, L/R Spread, Ceiling,
  Soft Attack, Limiter, Soft Clip, HQ 2x oversampling.

PRESETS
  Your own presets: Documents\YoukaiDigital\Youkai808\Presets

VERSION HISTORY
  v1.2
    - 25 effects, including Slow Fuzz, Intro FX, Attack Shaper, Mod EQ and Phaser
    - the 6 big knobs: DRIVE, CHAOS, FAT, MIX, BASS GUARD, OUTPUT
    - presets for every single effect + hover tooltips on everything
    - Goblins preset pack, 18 Signature presets
    - license activation (demo mode until activated)
    - the whole CRT screen shakes on hits
  v1.3
    - only Remilia shakes now - the CRT frame stays still
    - Goblin presets removed (Wobble Goblin stays)
    - shiny chain buttons, clearer effect tooltips
    - 19 Signature presets
  v1.4
    - TONE knob (ADVANCED tab): dark <-> bright
    - RANDOMIZE also rolls DRIVE, CHAOS, FAT, MIX and BASS GUARD (never OUTPUT)
    - presets never change your OUTPUT level
    - license keys only need your computer ID (no email)
    - 20 Signature presets
  v1.5
    - Waveshaper effect: 16 curves, MORPH between them, BIAS
    - NEW second plugin: Youkai808 Synth - makes the 808 itself (11 wavetables + load your own,
       glide, punch, decay, release, tune) and runs it through the same effect chain
    - 27 Signature presets
  v1.6
    - 9 808 samples in the Synth (Plugg Sub, Pluggnb 808, Punchy Sub, Stereo Sub, Zay 1,
       Zay Punchy, Zay Stereo, Ambient, Jugg Sub) - tuned to C, played across the keyboard
    - Synth envelope: ATTACK, DECAY, RELEASE, TENSION + a little envelope picture
    - RANDOMIZE: Waveshaper in about half the chains, a lot less chorus / phaser / SFX
  v1.7
    - 4 new effects: Busted Speaker, Auto-Wah, Boing, Fly-By
    - CURSED: drag Remilia's screen up to curse everything
    - 29 Signature presets
  v1.8
    - VERSIONS button: update notice + download any version from v1.2 up
    - COMMUNITY presets: a shared online preset bank everyone gets automatically
  v1.9   <-- this version
    - FREE TRIAL: without a license the first 3 presets are playable, the rest unlock when you buy
    - buy + activate inside the new Youkai Digital Hub app (no copy-paste keys)
    - updates now come from GitHub (faster, always up)
    - store keys lock to your computer and re-check online so leaked keys stop working

More music: https://soundcloud.com/skarletbandxz
