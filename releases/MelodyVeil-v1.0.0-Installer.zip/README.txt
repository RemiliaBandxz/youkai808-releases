MELODY VEIL  -  YoukaiDigital
=============================
Put it on your beat, or on a bus with all your melody tracks. It carves room in the middle
so your vocal sits on top without crazy mixing.

VEIL       how much room to carve (only cuts what is actually too loud)
LEAD       makes the catchy lead melody jump out (harmonics + presence around FOCUS)
FOCUS      where your lead lives (300 Hz - 5 kHz); sweep it with LEAD up
WIDTH      stereo width above 120 Hz (wider melodies = more room in the middle)
PUNCH      brings back drum hits a heavy master flattened
SMEAR / MUD / BOX / POCKET sliders  how hard each range may cut (0-150%)
MIX        blend with the untouched beat
OUTPUT     final level (auto gain keeps it as loud as it came in)
VOCAL KEY  send your vocal to the sidechain input: the pocket only opens while you rap
           (FL Studio: on the vocal's mixer track, right-click the arrow to the beat's track > "Sidechain to this track",
            then pick the sidechain input in Melody Veil's wrapper settings)

Presets: Clear (default), Sheer (subtle), Lead Focus, Veiled, Unsquash (for slammed YouTube beats), Ghost (vocal key).

Activate with the license key from your store email, or in Youkai Digital Hub.
