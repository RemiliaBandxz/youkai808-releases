YoukaiDigital Hub v1.0 (Windows)
Install, update, roll back and uninstall YoukaiDigital plugins, and activate license keys.

Just run "YoukaiDigital Hub.exe" (no install needed - put it anywhere, e.g. your Desktop).
If Windows says "Windows protected your PC": More info > Run anyway.
Installing/updating opens the plugin installer: close your DAW first.
