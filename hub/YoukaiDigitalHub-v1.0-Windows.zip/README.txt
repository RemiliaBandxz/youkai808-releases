YOUKAI DIGITAL HUB (Windows)
============================
1. Unzip this folder anywhere.
2. Run "Youkai Digital Hub.exe".
3. Browse plugins, start a free trial, or unlock with your license key.

One key works on up to 3 computers. No account needed.
(c) 2026 YoukaiDigital - Proprietary. See EULA.txt.
