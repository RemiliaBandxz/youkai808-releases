YOUKAI DIGITAL HUB
(c) 2026 YoukaiDigital. All rights reserved.

One app to get every YoukaiDigital plugin: browse, buy, activate, install, update and switch versions.

RUN
  Double-click "Youkai Digital Hub.exe". No install needed. Windows may say "Windows protected
  your PC" the first time: click More info > Run anyway.

WHAT IT DOES
  - Shows every plugin with its trial, price and whether you own it.
  - BUY opens checkout; the moment you pay, the plugin unlocks in the app (nothing to copy-paste).
  - ACTIVATE KEY pastes a license key you already have.
  - INSTALL / UPDATE downloads and runs the plugin's installer for you.
  - VERSIONS lets you install any older version.
  - MOVE LICENSE frees your key from this computer so you can use it on another one.

Your plugin list and updates are read online, so new plugins show up here automatically.
