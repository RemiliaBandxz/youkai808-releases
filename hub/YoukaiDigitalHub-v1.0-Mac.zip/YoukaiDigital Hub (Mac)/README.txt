YoukaiDigital Hub v1.0 (Mac)
Install, update, roll back and uninstall YoukaiDigital plugins, and activate license keys.

Drag "YoukaiDigital Hub" into Applications.
First launch: right-click it > Open > Open (it isn't from the App Store).
Installing/updating opens the plugin installer: close your DAW first.
